SELECT N_zach FROM Sessia
WHERE Mark=5
