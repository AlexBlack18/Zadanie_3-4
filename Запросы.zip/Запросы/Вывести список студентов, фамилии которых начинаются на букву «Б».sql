SELECT * FROM Students
WHERE Last_Name LIKE '�%';