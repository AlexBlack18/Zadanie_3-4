create table spec (
kod_spec int primary key not null,
spec nvarchar (70) not null
);