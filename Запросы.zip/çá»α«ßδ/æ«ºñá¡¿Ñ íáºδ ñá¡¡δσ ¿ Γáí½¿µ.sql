create database Oumartinen_Zajceva_P36
create table Groops (
N_groop int primary key not null,
kod_spec nvarchar(70) not null,
);
create table Sessia (
N_zach int primary key not null,
Discipline nvarchar(70) not null,
Date_ex date not null,
Mark int not null
);
create table Students (
N_Zach int primary key not null,
Last_Name nvarchar (70) not null,
First_Name nvarchar (70) not null,
Middle_Name nvarchar (70) not null,
N_groop nvarchar (70) not null
);
create table spec (
kod_spec int primary key not null,
spec nvarchar (70) not null
);
create table uch_plan (
kod_spec int primary key not null,
Discipline nvarchar (70) not null
);