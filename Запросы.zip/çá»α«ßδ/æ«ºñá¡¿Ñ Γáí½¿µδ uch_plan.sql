create table uch_plan (
kod_spec int primary key not null,
Discipline nvarchar (70) not null
);