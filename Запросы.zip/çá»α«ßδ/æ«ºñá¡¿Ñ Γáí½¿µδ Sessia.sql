create table Sessia (
N_zach int primary key not null,
Discipline nvarchar(70) not null,
Date_ex date not null,
Mark int not null
);