SELECT * FROM spec;
