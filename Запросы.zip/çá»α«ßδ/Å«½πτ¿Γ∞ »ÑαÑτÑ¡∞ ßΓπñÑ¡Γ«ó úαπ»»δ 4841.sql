SELECT Last_Name, First_Name, Middle_Name FROM Students
WHERE N_groop=4841