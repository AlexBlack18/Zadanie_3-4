create table Groops (
N_groop int primary key not null,
kod_spec nvarchar(70) not null,
);