SELECT * FROM Sessia;
