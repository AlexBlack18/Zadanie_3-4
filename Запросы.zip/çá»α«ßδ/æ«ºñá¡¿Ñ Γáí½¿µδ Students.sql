create table Students (
N_Zach int primary key not null,
Last_Name nvarchar (70) not null,
First_Name nvarchar (70) not null,
Middle_Name nvarchar (70) not null,
N_groop nvarchar (70) not null
);